contenido

navbar tipo anvorguesa incluyendo markdowns(?) 
inicio/
historia /nuestro refugio. (historia con una fotito) en la parte de nuestro refugio colocar un carrusel de imagenes
adopta 
Tienda solidaria 
visitanos 
contacto 
oportunidad laboral -voluntariado
-------------------------------------------
hero. imagen de perrito y gato 

botones dentro del hero 
adoptame
hogar temporal 
donacion 
-------------------------------------------

historia /word listo :3 paz <3 

-------------------------------------------
-elementos de la web------------------------
---seccion de ayuda---
otras formas de ayudar
donacion 
hogar temporal 
voluntariado 

botones para cada uno * 

----------------------------------------------
subscripcion de boletin con perritos 

------------------------------------------- 
 foooter
------------------------------------------- 
mapa 
dirección  
contacto 
formulario
equeño formulario 
redes sociales

back to top boton de retorno 
------------------------------------
instructivo para otras donaciones (alimentos , ropa , juguetes , medicinas)



webs de referencia 

https://www.territoriodezaguates.com/?gad_source=1&gad_campaignid=20105766682&gbraid=0AAAAABwzfZe0Ywtk3HqCNmogd8eo5dMIu&gclid=Cj0KCQiAy6vMBhDCARIsAK8rOgmC9Yb0jpPFwYTe_dZuVnr_o9tJxEUQk9SgAxs79sDCPOptv9FIjo4aAoH8EALw_wcB 


https://redemptionpaws.org/ 


https://www.dogstrust.org.uk/

 
https://www.petmatch.cl/




https://anaaweb.org/  proceso de adopcion 


Historia 
dinopatitas 🐶🦕
En una isla llena de árboles gigantes y portones enormes de madera, había un refugio muy especial llamado Dinopatitas.
Cuando las puertas se abrían cada mañana, pareciera que ves dinosaurios… pero no, son perritos corriendo con pañuelos de colores y colitas moviéndose sin parar.
El parque está diseñado como una gran aventura: senderos con huellitas marcadas en el suelo, “zonas salvajes” de juegos y casitas que parecen pequeñas cuevas jurásicas. Los visitantes pueden pasar sin el temor a ser devorados, pero si a que les roben el corazón
Los “habitantes” del parque, pasean y juegan en los espacios abiertos con sus disfraces de dinosaurios feroces, esperando a la nueva familia que los vendrá a adoptar para llenar de energía una nueva casita jurásica. 
Te invitamos a llevarte un “rugido” que parece un ladrido, pero no lo es. Son el alma de un dinosaurio travieso que quiere ser parte de tu hogar. 🐾 💚
